<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Baris Bahasa Paginasi
    |--------------------------------------------------------------------------
    |
    | Baris bahasa berikut digunakan oleh perpustakaan paginasi untuk membangun
    | tautan paginasi sederhana. Anda bebas untuk mengubahnya sesuai dengan keinginan
    | Anda untuk menyesuaikan tampilan aplikasi Anda agar lebih sesuai.
    |
    */

    'previous' => '&laquo;',
    'next' => '&raquo;',

];
